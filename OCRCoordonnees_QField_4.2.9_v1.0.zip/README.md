# OCR Coordonnées — QField 4.2.9

Structure d'un plugin application QField valide.

## Contenu
- `main.qml` : point d'entrée du plugin.
- `metadata.txt` : métadonnées du plugin.

## Installation
Dans QField :
Settings → Plugins → Install plugin from URL

Le ZIP doit être installé comme plugin applicatif.

Important : `main.qml` est directement à la racine du ZIP.
