import QtQuick 2.15
import QtQuick.Controls 2.15
import org.qfield 1.0

Item {
    id: plugin

    property var toolbarButton

    Component.onCompleted: {
        toolbarButton = buttonComponent.createObject(null)
        iface.addItemToPluginsToolbar(toolbarButton)
    }

    Component.onDestruction: {
        if (toolbarButton)
            toolbarButton.destroy()
    }

    Component {
        id: buttonComponent

        ToolButton {
            text: "OCR"
            icon.name: "camera"
            Accessible.name: "OCR Coordonnées"

            onClicked: {
                ocrDialog.open()
            }
        }
    }

    Dialog {
        id: ocrDialog
        title: "OCR Coordonnées"
        modal: true
        x: Math.round((parent.width - width) / 2)
        y: Math.round((parent.height - height) / 2)
        width: Math.min(520, parent.width - 32)
        standardButtons: Dialog.Close

        contentItem: Column {
            width: parent.width
            spacing: 14
            padding: 18

            Label {
                text: "OCR Coordonnées"
                font.bold: true
                font.pixelSize: 22
                horizontalAlignment: Text.AlignHCenter
                width: parent.width
            }

            Label {
                text: "Choisissez la source de l'image à analyser :"
                wrapMode: Text.WordWrap
                width: parent.width
            }

            Button {
                text: "📷  Prendre une photo"
                width: parent.width
                height: 52
                onClicked: {
                    iface.mainWindow().displayToast("Photo : fonction prête pour l'intégration de la caméra.")
                }
            }

            Button {
                text: "📁  Importer une image"
                width: parent.width
                height: 52
                onClicked: {
                    iface.mainWindow().displayToast("Import : fonction prête pour l'intégration du sélecteur d'image.")
                }
            }

            Label {
                text: "Étape suivante : connecter le moteur OCR pour lire les tableaux, documents et dessins."
                wrapMode: Text.WordWrap
                width: parent.width
                opacity: 0.75
            }
        }
    }
}
