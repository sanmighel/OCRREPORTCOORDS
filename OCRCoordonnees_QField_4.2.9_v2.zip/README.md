# OCR Coordonnées — Version 2

Cette version ajoute une fenêtre qui s'ouvre directement lorsque le bouton OCR est pressé.

Contenu du ZIP à la racine :
- main.qml
- metadata.txt
- README.md

La fenêtre contient :
- Prendre une photo
- Importer une image

La prochaine étape est l'intégration du moteur OCR réel et l'analyse automatique des coordonnées.
