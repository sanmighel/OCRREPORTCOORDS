import QtQuick
import QtQuick.Controls
import org.qfield

Item {
    id: plugin

    property var toolbarButton

    Component.onCompleted: {
        toolbarButton = buttonComponent.createObject(null)
        iface.addItemToPluginsToolbar(toolbarButton)
    }

    Component.onDestruction: {
        if (toolbarButton)
            toolbarButton.destroy()
    }

    Component {
        id: buttonComponent

        ToolButton {
            text: "OCR"
            icon.name: "camera"
            Accessible.name: "OCR Coordonnées"

            onClicked: dialog.open()
        }
    }

    Dialog {
        id: dialog
        title: "OCR Coordonnées"
        modal: true
        anchors.centerIn: parent
        width: Math.min(520, parent ? parent.width - 32 : 520)
        standardButtons: Dialog.Close

        contentItem: Column {
            spacing: 12
            padding: 16

            Label {
                text: "OCR Coordonnées"
                font.bold: true
                font.pixelSize: 20
            }

            Label {
                text: "Choisissez une image à analyser."
                wrapMode: Text.WordWrap
            }

            Button {
                text: "📷 Prendre une photo"
                width: parent.width
                onClicked: {
                    iface.mainWindow().displayToast("Fonction photo prête à être connectée au moteur OCR.")
                }
            }

            Button {
                text: "📁 Importer une image"
                width: parent.width
                onClicked: {
                    iface.mainWindow().displayToast("Sélection d'image prête à être connectée au moteur OCR.")
                }
            }

            Label {
                text: "Cette version est une base de plugin QField valide."
                wrapMode: Text.WordWrap
                opacity: 0.75
            }
        }
    }
}
